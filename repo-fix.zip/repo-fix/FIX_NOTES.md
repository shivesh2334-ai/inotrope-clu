# Fixes for shivesh2334-ai/inotrope-clu

## 1. Bug fix (functional) — beta-blocker filter was silently deleting Dobutamine

**File(s):** `public/index.html` and `cs-inotrope-selector.html` (both contain the same
bug — they're duplicates, see hygiene note below).

**What was wrong:** in the recommendation renderer, this line:

```js
return d!=='Dobutamine' || false; // keep dobutamine but flag below
```

evaluates to `d !== 'Dobutamine'`, i.e. it *removes* Dobutamine from the first-line
list whenever "Chronic beta-blocker therapy: Yes" + "Normotensive CS" are selected,
for every aetiology. The comment next to it says the intent was to keep Dobutamine
visible and just show a caution flag — the code did the opposite of the comment.
Clinically this matters: dobutamine isn't contraindicated with chronic beta-blockade
per the source review, it's just potentially blunted, which is exactly what the
existing warning flag already explains. So a clinician using the tool with a
beta-blocked, normotensive patient was never being shown dobutamine as an option
at all, silently.

**Fix applied:** removed the filter — all aetiology-appropriate agents are now always
shown; the existing beta-blocker warning flag still fires and explains the caveat.
Replace the two files with the corrected copies attached, or apply `index.html.patch`.

## 2. Hygiene (not a bug, but worth cleaning up before this repo grows)

- **No `.gitignore` existed.** Added one (attached) — excludes `node_modules/`,
  `__pycache__/`, generated `figures/` and `results*.json`, and `.vercel`. Without
  this, the next `npm install` + careless `git add .` from a local machine would
  commit the entire `node_modules/` tree.
- **Duplicate files across three locations.** `cs-inotrope-selector.html` (root) and
  `public/index.html` are byte-identical; same for `sheet-provisioner.gs` (root) vs
  `google-apps-script/sheet-provisioner.gs`, and `cs-data-analysis-hub/` vs
  `analytics/`. These were duplicated when the delivered zip got extracted directly
  into the repo root on top of the already-organized folders. Recommend keeping only
  the organized copies (`public/`, `google-apps-script/`, `analytics/`) and deleting
  the root-level duplicates — otherwise a future edit to one copy silently doesn't
  apply to the other, which is exactly how bugs like #1 above go unfixed in one file
  and stay broken in the other.
- **Committed binaries.** `cs-vasoactive-platform.zip`, `cs-vasoactive-platform-complete.zip`,
  and `cs_manuscript_draft.docx` (256 KB total) are checked into git. They're just
  the demo deliverables from chat, already redundant with the unpacked source in the
  repo, and binary diffs bloat `.git` history forever (deleting the file later doesn't
  shrink the repo — the blob stays in history). Recommend removing them from version
  control; keep them as local downloads if you want them, not committed.

### Suggested cleanup (via GitHub web UI, matching your usual workflow)
1. Delete: `cs-inotrope-selector.html`, `sheet-provisioner.gs`, `cs-data-analysis-hub/`
   (root-level duplicates only — keep `public/`, `google-apps-script/`, `analytics/`)
2. Delete: `cs-vasoactive-platform.zip`, `cs-vasoactive-platform-complete.zip`,
   `cs_manuscript_draft.docx`
3. Add `.gitignore` (attached)
4. Replace `public/index.html` with the fixed copy attached (also update the root
   `cs-inotrope-selector.html` copy if you keep it instead of deleting it)

## Verified working
- `npm install && npm start` → server boots clean, `/health` returns `{"ok":true,...}`,
  `/` and any unmatched path both correctly serve `public/index.html` (SPA-style
  fallback works as written).
- `vercel.json`'s legacy `builds`/`routes` format still works with `@vercel/node` —
  no deploy-breaking issue found there. (It's the older config style; Vercel's
  newer zero-config detection would also work if you ever want to simplify it, but
  nothing is currently broken.)
